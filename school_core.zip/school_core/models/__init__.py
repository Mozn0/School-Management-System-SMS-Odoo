from . import school_student, school_class, academic_year, school_subject, school_teacher, school_class_subject, school_section
from . import school_exam , school_attendance, school_fee, school_parent
